Security hardening applied (v2). CSRF helper inserted with non-strict fallback to preserve legacy flows. http_get2 hardened. Zip extraction guarded. Webhook only HTTPS.
